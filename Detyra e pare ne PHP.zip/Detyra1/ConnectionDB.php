<?php
    $username = "root";
    $dbname = "testdb";
    $password = "";
     $servername = "localhost";
   

     //Create connection
   $conn = mysqli_connect($servername, $username, $password);

   // Check connection
   if ($conn->connect_error) {
       die("Connection failed: " . $conn->connect_error);
   }
   

    //  echo "Connected successfully";

   if(!mysqli_select_db($conn,$dbname)){
       die("Connection to db failed");
   }


   $emri = $_POST['emri'];
   $mbiemri = $_POST['mbiemri'];
   $email = $_POST['email'];
   $tel = $_POST['tel'];
   $mesazhi=$_POST['mesazhi'];

$sql = "INSERT into user (emri , mbiemri,email, tel, mesazhi) VALUES ('$emri','$mbiemri','$email','$tel', '$mesazhi')";

  if (mysqli_query($conn, $sql)) {
        echo "New record created successfully";
        $to_email = $email;
        $subject = $email." has sent you a message" ;
        $message = $mesazhi."\n"."-- ".$emri." ".$mbiemri."\n".$tel;
        $headers = 'From:'.$email;

        mail($to_email,$subject,$message,$headers);
        echo("<br></br> Email was send to  ".$email)  ;
        //echo("<br></br>".$mesazhi)  ;
        //echo("<br></br>".$mesazhi)  ;


    } else {
     echo "Error: " . $sql . "<br>" . mysqli_error($conn);
    }
 ?>

 